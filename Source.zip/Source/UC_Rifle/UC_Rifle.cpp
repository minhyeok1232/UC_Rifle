// Copyright Epic Games, Inc. All Rights Reserved.

#include "UC_Rifle.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, UC_Rifle, "UC_Rifle" );
